// TSR.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include "stdafx.h"
#include "image_segmentation.h"

int _tmain(int argc, _TCHAR* argv[])
{
   Mat image=imread("images/roadsign_1.jpg");
   if (image.empty())
   {
	   cout<<"reading image is  wrong"<<endl;
	   system("pause");
	   return -1;  
   }
   long tstart,tend;
   Mat r,y,b;
   vector<Mat> object;
   tstart =clock();
   colordivision(image,r,y,b);
   imshow("b",b);
   imshow("y",y);
   imshow("r",r); 
   objectsegment(object,image,r,TSR_CIRCLE,true);
   imshow("test",image);
   tend=clock();
   cout<<tend -tstart<<endl;
   waitKey(0);
	return 0;
}

