#include <string>
#include <list>
#include <vector>
#include <map>
#include <stack>
#include "opencvhead.h"

void icvprCcaByTwoPass(const cv::Mat& _binImg, cv::Mat& _lableImg);
void icvprCcaBySeedFill(const cv::Mat& _binImg, cv::Mat& _lableImg);