#include "stdafx.h"
#include "image_segmentation.h"

/*******************************
function name:
function description��
function variable��
*******************************/
/******************************* ��ͨ��־Ŀ����ȡ����*******************************/
/*******************************
function name:
function description�� to mask  get inside object (final function)
function variable��input src image  choose: division variable    
                   shape(circle-3,rectangle-4,or triangle-5)
				   color(red-0,yellow-1,blue-2)
                   Isdrawrectangle  to draw the rectangle of object region   
*******************************/
void   objectsegment(vector<Mat> &object,Mat &image,Mat &single,int color,int shape,bool Isdrawrectangle)
{
	if (single.empty()||single.channels()!=1||image.empty()||image.channels()!=3) //���
	{
		//cout<<"function at objectsegment:src  image is  wrong"<<endl;
		system("pause");
		return ;
	}
	/******�����ڴ�***********/
	vector<Rect> rect;    //���ο�
	vector<Mat>  roi;     //ԭͼĿ������
	vector<Mat>  roimask; //��ֵ��ͼ����Ĥ
	unsigned int objectnumber=10;   //һ����ദ�����ٸ�Ŀ��
	object.clear();
	object.reserve(objectnumber);   //�����ȡ10��Ŀ��
	/******��ֵ������***********/
	bwprocess(single);
	/******Ѱ��Ŀ����״����***********/
	findregion(image,single,rect,shape,Isdrawrectangle);
	/******��ȡĿ����״����***********/
	getROI(image,rect,roi);
	getROI(single,rect,roimask);
	/******��ȡ�����������ڲ�ͼ��***********/
	for (unsigned int i=0;i<roi.size();i++)
	{   	
		if (i>objectnumber-1)
		   break;
		object.push_back(resizeprocess(roi[i],roimask[i],color,shape));
	}
	/******�ͷ��ڴ�***********/
	rect.~vector<Rect>();
	roi.~vector<Mat>();
	roimask.~vector<Mat>();
}
/*******************************
function name:
function description�� two image mask get common region
function variable��
*******************************/
/*******************************
function name:
function description:ȥ������ĺ�ɫ��������ȡ��С��Ӿ��Σ�������һ������ ���������32X32
function variable��
*******************************/
Mat resizeprocess(Mat &bworiginal,Mat &bwdivided,int color,int shape)
{
	if (bworiginal.empty()||bwdivided.empty())
	{
		//cout<<"error at function resizeprocess  input image is empty!"<<endl;
		system("pause");
		exit(1);
	}
	Mat object=imagemask(bworiginal,bwdivided,color,shape);
	Mat tmp_img;
	//object(getrect(object)).copyTo(tmp_img);
	object.copyTo(tmp_img);
	object.release();
	Size tsize;  //��һ���ߴ�
	if (shape==TSR_CIRCLE)
	   tsize=TSR_SIZE_CIRCLE;
	else if(shape==TSR_TRIANGLE)
	   tsize=TSR_SIZE_TRIANGLE;
	else
	{
		double rate=double(bwdivided.cols)/bwdivided.rows;
		if (rate>1.675)
			tsize=TSR_SIZE_RECTANGLE_2;
		else if(rate>1.175)
			tsize=TSR_SIZE_RECTANGLE_1;
		else if (rate>0.7)
		    tsize=TSR_SIZE_SQUARE;
		else
           tsize=TSR_SIZE_RECTANGLE_3;  
	}
	resize(tmp_img,tmp_img,tsize,0,0,INTER_LINEAR);
	//Canny(tmp_img,tmp_img,10,60,3); 
	return tmp_img;
}
Mat imagemask(Mat &bworiginal,Mat &bwdivided,int color,int shape)
{
	Mat object;
	if (bworiginal.empty()||bworiginal.channels()!=3||bwdivided.empty()||bwdivided.channels()!=1)
	{
		cout<<"function at imagemask: input image wrong"<<endl;
		system("pause");
	}
	cvtColor(bworiginal,bworiginal,CV_BGR2GRAY);
	int constvalue=10;
	if (color==TSR_BLUECOLOR&&shape==TSR_CIRCLE)
	{
	   int blocksize=65;
	   constvalue=5;
	   adaptiveThreshold(bworiginal,bworiginal,TSR_MAXVALUE,CV_ADAPTIVE_THRESH_MEAN_C,CV_THRESH_BINARY_INV,blocksize,constvalue);
	}
	else if(color==TSR_BLUECOLOR&&shape==TSR_RECTANGLE)
	{
		int blocksize=55;
		adaptiveThreshold(bworiginal,bworiginal,TSR_MAXVALUE,CV_ADAPTIVE_THRESH_MEAN_C,CV_THRESH_BINARY,blocksize,constvalue);
	}
	else if (color==TSR_REDCOLOR)
	{
		int blocksize=35;
		adaptiveThreshold(bworiginal,bworiginal,TSR_MAXVALUE,CV_ADAPTIVE_THRESH_MEAN_C,CV_THRESH_BINARY_INV,blocksize,constvalue);
	}
	else
	{
		int blocksize=15;
		equalizeHist(bworiginal,bworiginal);
		adaptiveThreshold(bworiginal,bworiginal,TSR_MAXVALUE,CV_ADAPTIVE_THRESH_MEAN_C,CV_THRESH_BINARY,blocksize,constvalue);
	}
	//equalizeHist(bworiginal,bworiginal);
	//dilate(bworiginal,bworiginal,Mat());
	erode(bwdivided,bwdivided,Mat());
	object=bwdivided&bworiginal;
	//bworiginal.copyTo(object,bwdivided);
	//morphologyEx(object,object,CV_MOP_OPEN,Mat());
	return object;
}
/*******************************
function name:
function description:Ѱ����С��Ӿ���
function variable��
*******************************/
Rect  getrect(Mat &src)
{
	int nl= src.rows; //����
	int nc= src.cols; // ÿ�е�Ԫ�ظ�����
	int v_max=20;    //��ֱͶӰ
	int v_min=0;
	int h_max=20;    //ˮƽͶӰ
	int h_min=0; 
	int LIMITATION=8;
	int i,j;
	Rect rect;
	//��ֱͶӰ ���ϵ���Y
	for (j=0; j<nl; j++)
	{
		uchar* data= src.ptr<uchar>(j);
		int count_row=0;
		for ( i=0; i<nc; i++)
		{      
			if (data[i]>0)
				count_row++;
			else
				continue;
		} 
		if (count_row>LIMITATION)
		{
			v_min=j;
			break;
		}
	} 
	//��ֱͶӰ ���µ���
	for (j=nl-1; j>0; j--)
	{
		uchar* data= src.ptr<uchar>(j);
		int count_row=0;
		for ( i=0; i<nc; i++)
		{            			
			if (data[i]>0)
				count_row++;
			else
				continue;
		} 
		if (count_row>LIMITATION)
		{
			v_max=j;
			break;
		}
	} 
	//ˮƽͶӰ ��X
	for (j=0; j<nc; j++)
	{

		int count_col=0;
		uchar* data=NULL;
		for ( i=v_min; i<v_max; i++)
		{   
			data=  src.ptr<uchar>(i);  

			if (data[j]>0)
				count_col++;
			else
				continue;
		} 
		if(count_col>LIMITATION)
		{
			h_min=j;
			break;
		}
	}
	//ˮƽͶӰ ���ҵ���
	for (j=nc-1; j>0; j--)
	{
		int count_col=0;
		uchar* data=NULL;
		for ( i=v_min; i<v_max; i++)
		{   
			data=  src.ptr<uchar>(i);        			
			if (data[j]>0)
				count_col++;
			else
				continue;
		} 
		if(count_col>LIMITATION)
		{
			h_max=j;
			break;
		}
	}
	rect.x=h_min;
	rect.y=v_min;
	rect.width =h_max-h_min;
	rect.height=v_max-v_min;
	return rect;
}
/*******************************
function name:
function description�� get  ROI  image
function variable��
*******************************/
void getROI(Mat &src,vector<Rect> & rect,vector<Mat> &signroi)
{
	if (src.empty()||rect.empty())
	{
		//cout<<"function at   getROI:the input srcimage or  rect vector is  empty!"<<endl;
		return;
	}
	//���roi
	signroi.clear();
	signroi.reserve(10);
	vector<Rect>::iterator p=rect.begin( );
	Mat temp_img;
	while(p!=rect.end())
	{
		src(*p).copyTo(temp_img);
		signroi.push_back(temp_img);
		p++;
	}
	temp_img.release();
}
/*******************************
function name:void findSquares(  Mat& image ,Mat&bw)
function description��to decide connected region is traffic sign  if yes  then return the  bounding rect coordinate
function variable��
*******************************/
void findregion(Mat& image ,Mat&bw,vector<Rect> &signroi,int whichshape,bool Isdrawrectangle)
{
	Mat gray;
	//��������Ƿ�Ϊ��ֵ��ͼ
	if (bw.empty()||bw.channels()!=1)
	{
		cout<<"function at findSquares :the input bw  is  wrong!"<<endl;
		return;
	}
	//COPY
	bw.copyTo(gray);
	//Canny(gray, gray, 0, 10, 5);  ���ñ�Ե��� ���������ٶ�
	vector< vector<Point> > contours;
	//��ȡ����
	findContours(gray, contours,CV_RETR_EXTERNAL,CV_CHAIN_APPROX_SIMPLE);
	// test each contour
	if (whichshape == TSR_CIRCLE )
	   findCircleRegion(image,bw,contours,signroi,Isdrawrectangle);
	else if (whichshape ==  TSR_RECTANGLE)
	   findRectangleRegion(image,bw,contours,signroi,Isdrawrectangle);
	else if (whichshape == TSR_TRIANGLE)
	   findTriangleRegion(image,bw,contours,signroi,Isdrawrectangle);
	else
	{
		cout<<"function at findregion :shape is not included!"<<endl;
		gray.release();
		return;
	}
	gray.release();
}

/*******************************
function name:
function description��find  round sign
function variable��
*******************************/
void findCircleRegion(Mat& image ,Mat&bw,vector< vector<Point> > contours,vector<Rect> &signroi,bool Isdrawrectangle)
{
	for( size_t i = 0; i < contours.size(); i++ )
	{
		Rect  rect;
		if (isCircleSignRegion(bw,contours[i],rect))
		{
			adjustroi(bw.cols,bw.rows,rect); //��ֹroiԽ��
			signroi.push_back(rect);     
			if (Isdrawrectangle)                           //�Ƿ񻭳�Ŀ��������Ӿ���
				rectangle(image,rect,TSR_SCALAR,2,8, 0);
		}
		else
			continue;
	}
}
/*******************************
function name:
function description��find  rectangle sign
function variable��
*******************************/
void findRectangleRegion(Mat& image ,Mat&bw,vector< vector<Point> > contours,vector<Rect> &signroi,bool Isdrawrectangle)
{
	for( size_t i = 0; i < contours.size(); i++ )
	{
		Rect  rect;
		if (isRectangleSignRegion(image ,bw,contours[i],rect))
		{
			rectangle(bw,rect,Scalar(TSR_MAXVALUE),-1,8,0); //��Ĥ������
			adjustroi(bw.cols,bw.rows,rect); //��ֹroiԽ��
			signroi.push_back(rect);     
			if (Isdrawrectangle)                           //�Ƿ񻭳�Ŀ��������Ӿ���
				rectangle(image,rect,TSR_SCALAR,2,8, 0);
		}
		else
			continue;
	}
}
/*******************************
function name:
function description��find  triangle sign
function variable��
*******************************/
void findTriangleRegion(Mat& image ,Mat&bw,vector< vector<Point> > contours,vector<Rect> &signroi,bool Isdrawrectangle)
{
	for( size_t i = 0; i < contours.size(); i++ )
	{
		Rect  rect;
		if (isTriangleSignRegion(bw,contours[i],rect))
		{
			rectangle(image,rect,Scalar( 0, 255, 0), 2,8, 0);
			adjustroi(bw.cols,bw.rows,rect); //��ֹroiԽ��
			signroi.push_back(rect); 
			if (Isdrawrectangle)                           //�Ƿ񻭳�Ŀ��������Ӿ���
				rectangle(image,rect,TSR_SCALAR,2,8, 0);
		}
		else
			continue;
	}
}
/*******************************
function name:
function description��judge return roi  whether being out of range or not,if  yes,  then  adjust it
function variable��
*******************************/
void  adjustroi(int imagewidth,int imageheight,Rect &roi)
{
	if (roi.x<0)
		roi.x=0;
	if (roi.y<0)
		roi.y=0;
	if (roi.x+roi.width>imagewidth-1)
	   roi.width= imagewidth-1-roi.x;
	if (roi.y+roi.height>imageheight-1)
	   roi.height= imageheight-1-roi.y; 
	
}
/*******************************
function name:
function description��according to  contours ,to distinguish  the contours region is the circle traffic sign region or  not
                     if yes  return roi(true)  ,or return empty (false
function variable��
*******************************/
bool  isCircleSignRegion(Mat &bw,vector<Point> &contour,Rect &rect)
{
      rect = boundingRect(contour); 
	  double rate=double(rect.width)/rect.height;
	  if (rect.width>32&&rect.height>30&&rate>0.4&&rate<2.5)  //ȥ����С�������ͳ�������
	  {
		  Point2f center;
		  float   radius;
		  minEnclosingCircle(contour,center,radius); 
		  //�ж��Ƿ�����Բ�λ�Բ����
		  rate = PI*radius*radius/(rect.area());
		  //cout<<rate<<endl;
		  if (rate<0.8||rate>1.4)
		     return false;

		  //�ж�Ϊ����Բ�ν�ͨ��־
		  double lc=arcLength(contour,true)/(2*PI*radius);//ͨ��Բ�ܳ�������֮�� �ж��Ƿ�����ROI
		   if (lc<0.95)
		   {
			   //RECT  ���ܲ����� ������ROI
			   int width= int(2.3*radius);
			   int height = width;
			   //����roi rect
			   int x= int(center.x-(width>>1));
			   int y=int(center.y-(height>>1));
			   rect = Rect(x,y,width,height); 
			   radius=float(radius*1.05);
		   }
		   else
		   {
			   //����roi rect
			   rect.x= int(rect.x-rect.width*0.05);  
			   rect.y= int(rect.y-rect.height*0.05);
			   rect.width=int(rect.width*1.1);
			   rect.height=int(rect.height*1.1);

		   }
		  //��Ĥ�� ������ȡ��ͨ��־�ڲ�ͼ��
	      circle(bw,center,int(radius),Scalar(TSR_MAXVALUE),-1,8,0);  
		  return  true;
	  }
	  else
		  return false;
}
/*******************************
function name:
function description��to judge  the contour is  whether  rectangle region
                      if yes  return true,else  return false
function variable��
*******************************/
bool   isRectangleSignRegion(Mat& image ,Mat&bw,vector<Point> &contour,Rect &rect)
{
	rect = boundingRect(contour); 
	double rate=double(rect.width)/rect.height;
	if (rect.width>28&&rect.height>28&&rate>0.4&&rate<2.5)  //ȥ����С�������ͳ�������
	{
		double lc=arcLength(contour,true);//ͨ�������ܳ�������֮�� �ж��Ƿ�����ROI
		double rarea=abs(contourArea(contour,true));//��ȡ���
		double rate_l,rate_s;
		rate_l = lc/(2*(rect.width+rect.height));
		rate_s = rarea/(rect.area());
		//cout<<" l: "<<rate_l<<" s: "<<rate_s<<endl;
        
		//�ж�Ϊ����
		if (rate_l<1.15&&rate_l>0.85&&rate_s<1.15&&rate_s>0.85)
		    return  true;
		else
		{
			Mat tmp_image;
			image(rect).copyTo(tmp_image);
			hsvdivision(tmp_image,tmp_image,TSR_BLUECOLOR);  //ת����HSV�ռ� ͳ�����
			
			Mat element(2,2,CV_8U,Scalar(1));
			dilate(tmp_image,tmp_image,element,Point(-1,-1),2);
			morphologyEx(tmp_image,tmp_image,MORPH_OPEN,element);  //ȥ��СĿ��
			rate_s=double(countNonZero(tmp_image))/rect.area();
			//cout<<"rate_s 2:"<<rate_s<<endl;
			tmp_image.release();
			if (rate_s<1.15&&rate_s>0.85)
			{
				/*rect.x= int(rect.x-rect.width*0.05);
				rect.y= int(rect.y-rect.height*0.05);
				rect.width=(int)rect.width*1.1;
				rect.height=(int)rect.height*1.1; */
				return true;
			}
				
		}
		return false;
	}
	else
	   return false;
}
/*******************************
function name:
function description��to judge  the contour is  whether triangle region
                      if yes  return true,else  return false
function variable��
*******************************/
bool   isTriangleSignRegion(Mat &bw,vector<Point> &contour,Rect &rect)
{
	rect = boundingRect(contour); 
	double rate=double(rect.height)/rect.width;
	if (rect.width>20&&rect.height>15&&rate>0.6&&rate<1.1)  //ȥ����С�������ͳ�������
	{
		
		double rate_s = 2*abs(contourArea(contour,true))/(rect.area());//��ȡ�������Ӿ���֮��
		//cout<<"rate: "<<rate<<endl;
		//cout<<" rate s: "<<rate_s<<endl;
		if (rate_s<0.75||rate_s>1.35)                       //��һ��ȥ��������������
		  return false;
		triangleadjust(bw,rect,rate,rate_s);
		return true;
	}
	return false;
}
/*******************************
function name:
function description��������������ȡĿ������
function variable�� rate  rect.width/rect.height
*******************************/
void triangleadjust(Mat &bw,Rect &rect,double rate,double rate_s)
{
	int x,y;
	x=rect.x+(rect.width>>1);
	y=rect.y+(rect.height>>1);
	double expand=1.0;
	double wshift=0.05;
	double hshift=0.1;
	int    leftshift=0;
	if (rate>0.95)				//	�����εױ߲�����
	{
	   wshift=0.2;
	   leftshift=2;
	   if (rate_s<1.0)
	     hshift=0.15;
	}
	else if (rate>0.85)           //�ǳ��ӽ���������
	{
	  if (rect.width>80&&rect.height>80)
	  {
	    expand=1.1;
		hshift=0.05;
	  }
	  else
	   expand=1.1;
	}
	else if(rate>0.75)            // �����θ�ƫС
	   expand=1.2;
	else 
       expand=1.3;               //����ƫС
	rect.width=int(rect.width*(expand+wshift));
	rect.height=int(rect.height*(expand+hshift)); 
	rect.x=x-(rect.width>>1)-leftshift;
	rect.y=y-(rect.height>>1)-1;

	//����������  ��Ĥ������
	vector<Point> triangle;
	triangle.reserve(3);
	triangle.push_back(Point(rect.x+(rect.width>>1),rect.y));
	triangle.push_back(Point(rect.x,rect.y+rect.height));
	triangle.push_back(Point(rect.x+rect.width,rect.y+rect.height));
	fillConvexPoly(bw,triangle,Scalar(TSR_MAXVALUE),8,0);
	triangle.~vector<Point>();
}
/*******************************
function name:
function description����ȡ���ζȣ�Բ�ζȣ���ɢָ��
function variable��
*******************************/
void   getGeometricalFeature(vector<Point> &contour,double &roundness,double &rectangle,double &discrete)
{
	Rect rect = boundingRect(contour);
	double lth   = arcLength(contour,true);
	double carea = abs(contourArea(contour,true));
	Point2f center;
	float   radius;
	minEnclosingCircle(contour,center,radius); 
	roundness = 4*PI*carea/(lth*lth);
	rectangle = carea/(rect.width*rect.height);
	discrete  = lth*lth/carea;
}
/******************************* ��ͨ��־Ŀ����ȡ����*******************************/


/******************************* ��ֵ��ͼ��������*******************************/
void bwprocess(Mat bwsrc)
{

  Mat element(2,2,CV_8U,Scalar(1));
  dilate(bwsrc,bwsrc,element);
 //deletesmaller(bwsrc);
  Mat element2(2,2,CV_8U,Scalar(1));
  erode(bwsrc,bwsrc,element);
}
/*******************************
function name:
function description��to delete the smaller part of bw
function variable��
*******************************/
void deletesmaller(Mat &bwsrc)
{  
	int channel=bwsrc.channels();
	if (channel!=1||(bwsrc.empty()))                         //����Ƿ�Ϊ bwͨ��ͼ��
	{
		cout<<"function at deletesmaller:the source image channel is  wrong! or the image is empty"<<endl;
		return;
	}
	int nl= bwsrc.rows; //����
	int nc= bwsrc.cols;

	//ptrָ�뷨����  8�������
	for (int j=1; j<nl-1; j++)
	{
		uchar* bwfront= bwsrc.ptr<uchar>(j-1);
		uchar* bwcurrent= bwsrc.ptr<uchar>(j);
		uchar* bwback=  bwsrc.ptr<uchar>(j+1);
		
		for (int i=1; i<nc-1; i+=2)
		{   
			uchar cnt=0;
			//8 �����˲�
			cnt+=(bwfront[i-1]+bwfront[i]+bwfront[i+1])/TSR_MAXVALUE;
			cnt+=(bwcurrent[i-1]+bwcurrent[i+1])/TSR_MAXVALUE;
			cnt+=(bwback[i-1]+bwback[i]+bwback[i+1])/TSR_MAXVALUE;
			if (cnt>=4)
			  bwcurrent[i]=TSR_MAXVALUE;
			else
			  bwcurrent[i]=0;
		   //4�����˲�
			/*cnt+=(bwfront[i-1])/MAXVALUE;
			cnt+=(bwcurrent[i-1]+bwcurrent[i])/MAXVALUE;
			cnt+=(bwback[i-1]+bwback[i])/MAXVALUE;
			if (cnt>=3)
			bwcurrent[i]=255;
			else
			bwcurrent[i]=0;*/
		}                 
	}	

}
/******************************* ��ֵ��ͼ��������*******************************/

/*******************************RGB  �ռ䣺red blue yellow ͨ���ָ�� ���ض�ֵ��ͼ��*******************************/
/*******************************
function name:void  colordivision( Mat rgbimage,Mat &redbw,Mat &yellowbw,Mat &bluebw )
function description�� to divide the red ��yellow and blue color ,return r,y,b bw image;
function variable��
*******************************/
void  colordivision( Mat rgbimage,Mat &redbw,Mat &yellowbw,Mat &bluebw )
{
	int channel=rgbimage.channels();
	
	if (channel!=3)                         //����Ƿ�Ϊ 3ͨ��ͼ��
	{
		cout<<"function at colordivision: the source image channel is  wrong!"<<endl;
		return;
	}
	int nl= rgbimage.rows; //����
	int nc= rgbimage.cols *channel; // ÿ�е�Ԫ�ظ�����ÿ�е�������*��ɫͨ������RGB = 3��

	//
	 redbw = Mat::zeros(rgbimage.size(),CV_8U);//BW image
     yellowbw   = Mat::zeros(rgbimage.size(),CV_8U);//BW image
	 bluebw  = Mat::zeros(rgbimage.size(),CV_8U);//BW image
	
	//ptrָ�뷨����  ��ȡ�Ҷ�ͼ��
	for (int j=0; j<nl; j++)
	{
		
		uchar* rgb= rgbimage.ptr<uchar>(j);
		uchar* rbw= redbw.ptr<uchar>(j);
		uchar* ybw= yellowbw.ptr<uchar>(j);
		uchar* bbw= bluebw.ptr<uchar>(j);

		for (int i=0,p=0; i<nc; i+=channel,p++)
		{            			
			rbw[p]= getredpixel2(rgb[i+2],rgb[i+1], rgb[i]);
			ybw[p]= getyellowpixel(rgb[i+2],rgb[i+1], rgb[i]);
			bbw[p]= getbluepixel(rgb[i+2],rgb[i+1], rgb[i]);
		}                 
	}	
	//��ö�ֵͼ��
    threshold(redbw,redbw,getThreshVal_Otsu_8u(redbw),TSR_MAXVALUE,CV_THRESH_BINARY);
    threshold(bluebw,bluebw,getThreshVal_Otsu_8u(bluebw),TSR_MAXVALUE,CV_THRESH_BINARY);
   //threshold(yellowbw,yellowbw,getThreshVal_Otsu_8u(yellowbw),TSR_MAXVALUE,CV_THRESH_BINARY);
   //��ɫͼ��ͼ����ǿ
   vector<Mat> bgr(3);
   split(rgbimage,bgr);
   fillblackbound(bgr[0],yellowbw);
   bgr.~vector<Mat>();
}
/*******************************RGB  �ռ䣺red blue yellow ͨ���ָ�� ֱ�ӷ��ظ�ͨ����ֵ��ͼ��************************/


/*******************************HSV  �ռ䣺red blue yellow ͨ���ָ�� ֱ�ӷ��ظ�ͨ����ֵ��ͼ��************************/
/*******************************
function name:void hsvdivision(Mat &src,Mat &division,int whichcolor)
function description�� at HSV space to divide  red blue  yellow channel
function variable��src  RGB srcimage   dst:division  whichcolor: 0-red 1-yellow 2-blue
*******************************/
void hsvdivision(const Mat &src,Mat &division,int whichcolor)
{
	int channel=src.channels();
	if (channel!=3)                         //����Ƿ�Ϊ 3ͨ��ͼ��
	{
		cout<<"function at colordivision: the source image channel is  wrong!"<<endl;
		return;
	}
	//�ռ�ת��
	Mat hsvimage;
	cvtColor(src,hsvimage,CV_BGR2HSV);
	division = Mat::zeros(hsvimage.size(),CV_8U);

	int nl= hsvimage.rows; //����
	int nc= hsvimage.cols *channel; // ÿ�е�Ԫ�ظ�����ÿ�е�������*��ɫͨ������HSV = 3��
	//�ָ�
	//ptrָ�뷨����  ��ȡ�Ҷ�ͼ��
	for (int j=0; j<nl; j++)
	{
		uchar* hsv= hsvimage.ptr<uchar>(j);
		uchar* dchannel= division.ptr<uchar>(j);
		for (int i=0,p=0; i<nc; i+=channel,p++)
		{            			
			dchannel[p]=hsvtosinglechannel(hsv[i],hsv[i+1],whichcolor);
		}                 
	}	
	//��ö�ֵͼ��
	threshold(division,division,TSR_MAXVALUE>>1,TSR_MAXVALUE,CV_THRESH_BINARY);
	hsvimage.release();
}
/*******************************HSV  �ռ䣺red blue yellow ͨ���ָ�� ֱ�ӷ��ظ�ͨ����ֵ��ͼ��************************/


/*******************************��ֵ���㷨����*******************************/
/*******************************
function name:getThreshVal_Otsu_8u( const Mat& _src )
function description��to get teh thresh of bw  //OTSU��ֵ�ָ�
function variable��
*******************************/
int  getThreshVal_Otsu_8u( const Mat& _src )
{
	Size size = _src.size();
	const int N = 256; int i, j, h[N] = {0}; 
	unsigned char* src; 
	for( i = 0; i < size.height; i++ ) 
	{ 
		src = _src.data + _src.step*i; 
		j = 0;
		for(j = 0; j < size.width; j++ )
			h[src[j]]++; } 
	double mu = 0, scale = 1./(size.width*size.height);
	for( i = 0; i < N; i++ )
	{
		mu += i*(double)h[i]; }  
	mu *= scale; 
	double mu1 = 0, q1 = 0; 
	double max_sigma = 0, max_val = 0; 
	for( i = 0; i < N; i++ )
	{ 
		double p_i, q2, mu2, sigma; 
		p_i = h[i]*scale; mu1 *= q1;
		q1 += p_i; q2 = 1. - q1; 
		if( std::min(q1,q2) < FLT_EPSILON || std::max(q1,q2) > 1. - FLT_EPSILON )
			continue; 
		mu1 = (mu1 + i*p_i)/q1;
		mu2 = (mu - q1*mu1)/q2;
		sigma = q1*q2*(mu1 - mu2)*(mu1 - mu2);
		if( sigma > max_sigma )
		{ 
			max_sigma = sigma; max_val = i;
		} 
	} 
	return (int)max_val;
} 
/*******************************��ֵ���㷨����*******************************/


/*******************************��ɫ�ָ��㷨����*******************************/
/*******************************
function name:
function description����ɫ���ֺ�ɫ�߽��
function variable��
*******************************/
void  fillblackbound(Mat &bluechannel,Mat  &bwyellow)
{
	if (bwyellow.channels()!=1||bluechannel.channels()!=1||(bluechannel.size!=bwyellow.size))                        //����Ƿ�Ϊ 3ͨ��ͼ��
	{
		cout<<"function at fillblackbound: the source image channel is  wrong or not in the same size!"<<endl;
		return;
	}
	int nl= bwyellow.rows; //����
	int nc= bwyellow.cols ; // ÿ�е�Ԫ�ظ�����ÿ�е�������
	//PTR
	for (int j=1; j<nl-1; j++)
	{
		 //8�������ɫ�߽�
		uchar* bw=bwyellow.ptr<uchar>(j);
		uchar* prebw=bwyellow.ptr<uchar>(j-1);
		uchar* nextbw=bwyellow.ptr<uchar>(j+1);
		uchar* gray=bluechannel.ptr<uchar>(j);
		uchar* pregray=bluechannel.ptr<uchar>(j-1);
		uchar* nextgray=bluechannel.ptr<uchar>(j+1);
		for (int i=1; i<nc-1; i++)
		{       
			if (bw[i]>0)
			{        
				if (j>10)
				{
					uchar cnt=0;
					for(int m=1;m<10;m++)
					{
						if (bwyellow.at<uchar>(j-m,i)>0)
							cnt++;
					}
					if (cnt<3)
						continue;
				}
				     if (bw[i-1]==0)    bw[i-1]=getblackpixel(gray[i-1]);
					 if (bw[i+1]==0)    bw[i+1]=getblackpixel(gray[i+1]);
					 if(prebw[i-1]==0)  prebw[i-1]=getblackpixel(pregray[i-1]);
					 if(prebw[i]==0)    prebw[i]=getblackpixel(pregray[i]);
					 if(prebw[i+1]==0)  prebw[i]=getblackpixel(pregray[i+1]);
					// if(nextbw[i]==0)    nextbw[i]=getblackpixel(nextgray[i]);
			}
			else
			   continue;
		}                 
	}	
}
/*******************************
function name:
function description��to decide  is red color
function variable��
*******************************/
uchar  getredpixel(uchar r,uchar g, uchar b)
{
	double delta=1.6*r-b-g;
	if (r-g>30&&r-b>30&&g-b<40&&g+b<250)// ���˻�ɫ
	   return getgrayvalue(delta);	
	else
	   return 0;
} 
uchar  getredpixel2(uchar r,uchar g, uchar b)
{
	double delta=1.6*r-b-g;
	if (r-g>30&&r-b>30&&g-b<40&&g+b<250)// ���˻�ɫ
	{
		if(delta>75)	
			return getgrayvalue(delta);
	}
    return 0;
}
/*******************************
function name:
function description��to decide  is blue color
function variable��
*******************************/
uchar  getbluepixel(uchar r,uchar g, uchar b)
{
	double delta=1.6*b-g-r+TSR_BLUEOFFSET;
	if (b-g>30&&b-r>50)
       return getgrayvalue(delta);	

	else
		return 0;
} 
/*******************************
function name:
function description��to decide  is yellow  color
function variable��
*******************************/
uchar  getyellowpixel(uchar r,uchar g, uchar b)
{
	double delta=g+r-b+TSR_YELLOWOFFSET;
	int  sum=r+g+b;
	if (r-b>28&&g-b>28&&r-g>-10)
		 return  TSR_MAXVALUE;
	else if(sum>135&&sum<165)     //�ڹ��߻谵��������
	{
		if (r-b>15&&g-b>15&&r-g>-10)
		  return TSR_MAXVALUE;
	}
	return 0;
} 
/*******************************
function name:
function description��to decide  is black  color
function variable��
*******************************/
uchar getblackpixel(uchar gray)
{
	if (gray<50)
	   return  TSR_MAXVALUE;
	else
	   return 0;
}
/*******************************
function name:
function description��to decide gray  color  value
function variable��
*******************************/
uchar  getgrayvalue(double delta)
{
	if(delta<0)	
		return 0;
	else if(delta>TSR_MAXVALUE)
		return TSR_MAXVALUE;
	else
		return (uchar)delta;	
}

/*******************************
function name:
function description��HSV divide color 
function variable��whichcolor  0-red  1-yellow 2-blue
*******************************/
uchar hsvtosinglechannel(uchar H,uchar S,int whichcolor)
{
	if (whichcolor==TSR_REDCOLOR)
	{
		if ((H>135||H<23)&&S>63)
			return TSR_MAXVALUE;
	}
	else if(whichcolor == TSR_YELLOWCOLOR)
	{
		if (H>9&&H<27&&S>54)
			return TSR_MAXVALUE;
	}
	else if (whichcolor == TSR_BLUECOLOR)
	{
		if (H>90&&H<135&&S>54)
			return TSR_MAXVALUE;
	}
	return 0;
}
/*******************************��ɫ�ָ��㷨����*******************************/







