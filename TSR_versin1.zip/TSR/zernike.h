#include "opencvhead.h"
const int  TSR_ZERNIKE_TABLE_N[8]={8,8,10,12,14,16,18,20};
const int  TSR_ZERNIKE_TABLE_M[8]={0,2, 0, 0, 0, 0,0,0};
const double  TSR_ZERNIKE_NORMALIZAITON[8]={0.13333,0.0666,400.0,9500.0,22000.0,12000.0,1800.0,11500.0};
void getZernikeMoment(const Mat &src, double Ze[8]);
void getZernikeMoment2(const Mat &src, double Ze[8]);
void gethumoments(const Mat &src, double hu[7]);
