// TSR.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include "stdafx.h"
#include "TSR.h"
#include "image_segmentation.h"
int _tmain(int argc, _TCHAR* argv[])
{
	int flag=1;
	//����������
	if (flag==1)
	{
		CvANN_MLP bpredcircle;
		CvANN_MLP bpredtri;
		CvANN_MLP bpbluecircle;
		CvANN_MLP bpbluerect;
		CvANN_MLP bpyellowtri;
		bpredcircle.load("data/redcircle.xml");
		bpredtri.load("data/redtri.xml");
		bpbluecircle.load("data/bluecircle.xml");
		bpbluerect.load("data/bluerect.xml");
		bpyellowtri.load("data/yellowtri.xml");
		//��ȡ��ʶ��ͼƬ
	   Mat image=imread("test/redtest/test_1.jpg");
		if (image.empty())
		{
			cout<<"reading image is  wrong"<<endl;
			system("pause"); 
			exit(1);
		}
		//R B Y�ָ�ͼƬ
		long tstart,tend;//����ʱ��
		Mat r,y,b;
		//����Ŀ������
		vector<Mat> object_redcircle;
		vector<Mat> object_redtri;
		vector<Mat> object_bluecircle;
		vector<Mat> object_bluerect;
		vector<Mat> object_yellowtri;
		//����ʶ��������
		vector<int> recognize_redcircle;
		vector<int> recognize_redtri;
		vector<int> recognize_bluecircle;
		vector<int> recognize_bluerect;
		vector<int> recognize_yellowtri;
		tstart =clock();
		//�ָ�
		colordivision(image,r,y,b);
		//���Ŀ��
		objectsegment(object_redcircle,image,r,TSR_REDCOLOR,TSR_CIRCLE,true);
		if (!object_redcircle.empty())
		{
			imshow("object",object_redcircle[0]);
		}
		//objectsegment(object_redtri,image,r,TSR_REDCOLOR,TSR_TRIANGLE,true);
		//objectsegment(object_bluecircle,image,b,TSR_BLUECOLOR,TSR_CIRCLE,true);
		//objectsegment(object_bluerect,image,b,TSR_BLUECOLOR,TSR_RECTANGLE,true);
		//objectsegment(object_yellowtri,image,y,TSR_YELLOWCOLOR,TSR_TRIANGLE,true);
	
		//ʶ��Ŀ��
		recognize(object_redcircle,recognize_redcircle,bpredcircle);
		//recognize(object_redtri,recognize_redtri,bpredtri);
		//recognize(object_bluecircle,recognize_bluecircle,bpbluecircle);
		//recognize(object_bluerect,recognize_bluerect,bpbluerect);
		//recognize(object_yellowtri,recognize_yellowtri,bpyellowtri);
		//����ʱ��
		tend=clock();
		if (!recognize_redcircle.empty())
		{
			cout<<recognize_redcircle[0]<<endl;
		}
		cout<<"TIMES:  "<<tend-tstart<<endl;
		//�ͷ��ڴ�
		object_redcircle.~vector<Mat>();
		object_redtri.~vector<Mat>();
		object_bluecircle.~vector<Mat>();
		object_bluerect.~vector<Mat>();
		object_yellowtri.~vector<Mat>();
		recognize_redcircle.~vector<int>();
		recognize_redtri.~vector<int>();
		recognize_bluecircle.~vector<int>();
		recognize_bluerect.~vector<int>();
		recognize_yellowtri.~vector<int>();
		////��ʾԴͼ��
		imshow("src",image);
		//��ʾ�ָ�ͼ��
		imshow("red",r);
		imshow("yellow",y);
		imshow("blue",b);
		waitKey(0);
	}
	//system("pause");

	else if(flag==2)
	{

		char filename[100];
		for(int j=0;j<=5;j++)
		{

			for (int i=1;i<=10;i++)
			{
				sprintf(filename,"trainimg/redcircle/red_%d%d.jpg",i,j);
				getfeature(filename);
				//getHufeature(filename);
			}
		}
	}
	else if(flag==3)
	{

		bp annbp;
		double samples[sample_num][innode]={0.0};
		double targets[sample_num][outnode]={0.0};
		annbp.readsamplesdata("data/redcircle.dat",samples);
		annbp.readlabelsdata("data/redcirclelabels2.dat",targets);
		CvANN_MLP bpnet; 
		// Set up BPNetwork's parameters
		CvANN_MLP_TrainParams params;
		//params.train_method=CvANN_MLP_TrainParams::BACKPROP;
		params.bp_dw_scale=0.1;
		params.bp_moment_scale=0.1;
		params.term_crit=cvTermCriteria(CV_TERMCRIT_ITER+CV_TERMCRIT_EPS,100000000000,0.0000000001);
		params.train_method=CvANN_MLP_TrainParams::RPROP;
		/*params.rp_dw0 = 0.1; 
		params.rp_dw_plus = 1.2; 
		params.rp_dw_minus = 0.5;
		params.rp_dw_min = FLT_EPSILON; 
		params.rp_dw_max = 50;*/
		Mat labelsMat(sample_num,outnode, CV_64FC1,targets);
		Mat trainingDataMat(sample_num,innode, CV_64FC1,samples);
		Mat layerSizes=(Mat_<int>(1,4) << innode,hidenode,hidenode,outnode);
		bpnet.create(layerSizes,CvANN_MLP::SIGMOID_SYM);//CvANN_MLP::SIGMOID_SYM//CvANN_MLP::GAUSSIAN//CvANN_MLP::IDENTITY
		long tstart,tend;
		tstart=clock();
		bpnet.train(trainingDataMat, labelsMat, Mat(),Mat(), params);
		tend=clock();
		cout<<"time: "<<tend-tstart<<endl;
		bpnet.save("data/redcircle.xml");
		bpnet.load("data/redcircle.xml");
		for(int j=0;j<6;j++)
		{
			Mat intest(1,8,CV_64FC1,samples[j*10+1]);
			Mat outest;
			bpnet.predict(intest,outest);
			for (int i=0;i<outest.cols;i++)
				cout<<outest.at<double>(0,i)<<endl;
			cout<<endl;
		}
		system("pause");
	}
	else
	{

		bp bpann;
		bpann.bp_init();
		double samples[sample_num][innode]={0.0};
		double targets[sample_num][outnode]={0.0};
		bpann.readsamplesdata("data/redcircle.dat",samples);
		bpann.readlabelsdata("data/redcirclelabels2.dat",targets);
		long times=0;
		while(bpann.error>0.0001)
       {
         times++;
         bpann.bp_train(samples,targets);
        cout<<"Times="<<times/1000<<" error="<<bpann.error<<endl;
	   }
		cout<<"trainning complete..."<<endl;
		bpann.writetrain("w_in2hide","w_hide2out");
	}
	return 0;
}

