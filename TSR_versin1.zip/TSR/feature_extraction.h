#include "opencvhead.h"
//void  gethumoments(const Mat &src,double hu[7]);
