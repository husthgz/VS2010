#include "opencvhead.h"

#define  TSR_BLUEOFFSET    50
#define  TSR_YELLOWOFFSET  50
#define  TSR_REDOFFSET     0
#define  TSR_MAXVALUE      255
#define  TSR_REDCOLOR      0
#define  TSR_YELLOWCOLOR   1
#define  TSR_BLUECOLOR     2
#define  TSR_CIRCLE        3
#define  TSR_RECTANGLE     4
#define  TSR_TRIANGLE      5
#define  TSR_SCALAR        Scalar(0,255,0)
#define  TSR_SIZE_TRIANGLE  Size(34,30)
#define  TSR_SIZE_CIRCLE     Size(50,50)
#define  TSR_SIZE_SQUARE     Size(50,50)
#define  TSR_SIZE_RECTANGLE_1 Size(63,48)
#define  TSR_SIZE_RECTANGLE_2 Size(60,30)
#define  TSR_SIZE_RECTANGLE_3 Size(30,60)
//compeleted  part  
void   objectsegment(vector<Mat> &object,Mat &image,Mat &single,int color,int shape,bool Isdrawrectangle);

//segmentation part
void   getROI(Mat &src,vector<Rect> & rect,vector<Mat> &signroi);
void   findregion(Mat& image ,Mat&bw,vector<Rect> &signroi,int whichshape,bool Isdrawrectangle);
void   findCircleRegion(Mat& image ,Mat&bw,vector< vector<Point> > contours,vector<Rect> &signroi,bool Isdrawrectangle);
void   findRectangleRegion(Mat& image ,Mat&bw,vector< vector<Point> > contours,vector<Rect> &signroi,bool Isdrawrectangle);
void   findTriangleRegion(Mat& image ,Mat&bw,vector< vector<Point> > contours,vector<Rect> &signroi,bool Isdrawrectangle);
void   getGeometricalFeature(vector<Point> &contour,double &roundness,double &rectangle,double &discrete);
bool   isCircleSignRegion(Mat &bw,vector<Point> &contour,Rect &rect);
bool   isRectangleSignRegion(Mat& image ,Mat&bw,vector<Point> &contour,Rect &rect);
bool   isTriangleSignRegion(Mat &bw,vector<Point> &contour,Rect &rect);
void   adjustroi(int imagewidth,int imageheight,Rect &roi);


//bw image process part
void   bwprocess(Mat bwsrc);
void   deletesmaller(Mat &bwsrc);
void   fillblackbound(Mat &bluechannel,Mat  &bwyellow);
void   triangleadjust(Mat &bw,Rect &rect,double rate,double rate_s);
Mat    resizeprocess(Mat &bworiginal,Mat &bwdivided,int color,int shape);
Mat    imagemask(Mat &bworiginal,Mat &bwdivided,int color,int shape);
Rect   getrect(Mat &src);
//color division
void   colordivision( Mat rgbimage,Mat &redbw,Mat &yellowbw,Mat &bluebw );
void   hsvdivision(const Mat &src,Mat &division,int whichcolor);

//Binary Process part 
int    getThreshVal_Otsu_8u( const Mat& _src );

//color division algorithm part 
uchar  getredpixel(uchar r,uchar g, uchar b);
uchar  getbluepixel(uchar r,uchar g, uchar b);
uchar  getyellowpixel(uchar r,uchar g, uchar b);
uchar  getgrayvalue(double delta);
uchar  getredpixel2(uchar r,uchar g, uchar b);
uchar  getblackpixel(uchar gray);
uchar  hsvtosinglechannel(uchar H,uchar S,int whichcolor);

