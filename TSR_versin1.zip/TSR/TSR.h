#include  "image_segmentation.h"
#include  "opencvhead.h"
#include  "zernike.h"
#include  "ANN_BP.h"
#define   TSR_RECOGNIZE_WRONG   100
static const  double   TSR_TABLE_REDRCIRCLE[10][outnode]={{1.0, 0.0,  0.0 ,  0.0 ,  0.0 , 0.0,0.0 ,0.0 , 0.0 , 0.0},
												{0.0, 1.0,  0.0 ,  0.0 ,  0.0 , 0.0,0.0 ,0.0 , 0.0 , 0.0},
												{0.0, 0.0,  1.0 ,  0.0 ,  0.0 , 0.0,0.0 ,0.0 , 0.0 , 0.0},
												{0.0, 0.0,  0.0 ,  1.0 ,  0.0 , 0.0,0.0 ,0.0 , 0.0 , 0.0},
												{0.0, 0.0,  0.0 ,  0.0 ,  1.0 , 0.0,0.0 ,0.0 , 0.0 , 0.0},
												{0.0, 0.0,  0.0 ,  0.0 ,  0.0 , 1.0,0.0 ,0.0 , 0.0 , 0.0},
												{0.0, 0.0,  0.0 ,  0.0 ,  0.0 , 0.0,1.0 ,0.0 , 0.0 , 0.0},
												{0.0, 0.0,  0.0 ,  0.0 ,  0.0 , 0.0,0.0 ,1.0 , 0.0 , 0.0},
												{0.0, 0.0,  0.0 ,  0.0 ,  0.0 , 0.0,0.0 ,0.0 , 1.0 , 0.0},
												{0.0, 0.0,  0.0 ,  0.0 ,  0.0 , 0.0,0.0 ,0.0 , 0.0 , 1.0}
                                               };
//��ȡ��������
void getfeature(char *filename)
{
	FILE *stream0;
	FILE *stream1;
	Mat image=imread(filename);
	if (image.empty())
	{
		cout<<"reading image is  wrong"<<endl;
		system("pause"); 
		exit(1);
	}
	if(( stream0 = fopen("data/redcircle.dat", "a"))==NULL)
	{
		cout<<"�����ļ�ʧ��!";
		system("pause");
		exit(1);
	}

	long tstart,tend;
	Mat r,y,b;
	vector<Mat> object;
	tstart =clock();
	colordivision(image,r,y,b);
	imshow("divide",b);
	objectsegment(object,image,r,TSR_REDCOLOR,TSR_CIRCLE,true);
	imshow("src",image);  
	if (!object.empty())
	{
		int i=0;
		double ze[8]={0.0};
		getZernikeMoment2(object[i],ze);
		imshow("object",object[i]);
		for(int j=0;j<8;j++)
		{
			fprintf(stream0, "%lf\t",ze[j]);
		}
		fprintf(stream0, "\n");
		fclose(stream0);
	}
	tend=clock();
	cout<<tend -tstart<<endl;
	waitKey(0);
}
void getHufeature(char *filename)
{
	FILE *stream0;
	FILE *stream1;
	Mat image=imread(filename);
	if (image.empty())
	{
		cout<<"reading image is  wrong"<<endl;
		system("pause"); 
		exit(1);
	}
	if(( stream0 = fopen("data/hu.dat", "a"))==NULL)
	{
		cout<<"�����ļ�ʧ��!";
		system("pause");
		exit(1);
	}

	long tstart,tend;
	Mat r,y,b;
	vector<Mat> object;
	tstart =clock();
	colordivision(image,r,y,b);
	imshow("divide",b);
	objectsegment(object,image,r,TSR_REDCOLOR,TSR_CIRCLE,true);
	imshow("src",image);  
	if (!object.empty())
	{
		int i=0;
		double ze[7]={0.0};
		gethumoments(object[i],ze);
		imshow("object",object[i]);
		for(int j=0;j<7;j++)
		{
			fprintf(stream0, "%lf\t",log(abs(ze[j])));
		}
		fprintf(stream0, "\n");
		fclose(stream0);
	}
	tend=clock();
	cout<<tend -tstart<<endl;
	waitKey(0);
}
int convertbinary2int(Mat &outdata)
{  
	if (outdata.empty()||outdata.rows!=1)
	{   
		    cout<<"fuction at  convetbinary2int :input is  empty or wrong"<<endl;
			return TSR_RECOGNIZE_WRONG;
	}
	/*double   curerror=0.0;
	double   minerror=100.0;
	double  *rdata=outdata.ptr<double>(0);
	int     mark;*/
	/*for(int i=0;i<ln;i++)  //����һ
	{
		curerror=0;
		for (int j=0;j<outdata.cols;j++)
		{
			 if (i==0)
			     cout<<rdata[j]<<endl;
			if (rdata[j]>1.1)
			  curerror+=abs(1.0-TSR_TABLE[i][j]);
			else if (rdata[j]<0.01)
			  curerror+=abs(0.0-TSR_TABLE[i][j]);
			else
			  curerror+=abs(rdata[j]-TSR_TABLE[i][j]);
		}
		cout<<i<<" "<<curerror<<endl;
		if (curerror<minerror)
		{
			mark=i;
			minerror=curerror;
		}
	}
	if (minerror>1.0)
	  return TSR_RECOGNIZE_WRONG;
	return mark;*/
    int mark;
	double maxvalue=0.0;
	double  *rdata=outdata.ptr<double>(0);
    for (int j=0;j<outdata.cols;j++)
	{
		cout<<rdata[j]<<endl;
		if (rdata[j]>maxvalue)
		{
			mark=j;
			maxvalue=rdata[j];
		}
		else
			continue;		 
    }
	if (maxvalue<0.65)
	  return TSR_RECOGNIZE_WRONG;
	return mark;
}

void recognize(vector<Mat> &object,vector<int> &redata,CvANN_MLP &bpnet)
{
	redata.clear();
	if (object.empty())
	{
		return ;
	}
	for (unsigned int i=0;i<object.size();i++)
	{   	
		double ze[innode]={0.0};
		getZernikeMoment2(object[i],ze);
		/*imshow("object",object[i]);
		waitKey(0);*/
		Mat indata(1,innode,CV_64FC1,ze);
		Mat outdata;
		bpnet.predict(indata,outdata);
		redata.push_back(convertbinary2int(outdata));
	}
}
void printhumements(Mat &src)
{
	double hu[7];
	Moments mm=moments(src,true);
	HuMoments(mm,hu);
	for (int i=0;i<7;i++)
	  cout<<"HU  "<<i<<" "<<log(hu[i])<<endl;
}

