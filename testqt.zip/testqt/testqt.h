#ifndef TESTQT_H
#define TESTQT_H

#include <QtWidgets/QMainWindow>
#include <QLabel>
#include <QPushButton>
#include <QFileDialog>
#include <QLineEdit>
#include "ui_testqt.h"
#include "image_segmentation.h"
#include "TSR.h"
#include "information.h"

class testqt : public QMainWindow
{
	Q_OBJECT

public:
	testqt(QWidget *parent = 0);
	~testqt();

private:                  //ͼƬ����
	Ui::testqtClass ui;
	Mat srcimage;
	Mat rimage;
	Mat bimage;
	Mat yimage;
	Mat aboutimage;
private:                   //��������
	//����Ŀ������
	vector<Mat> object_redcircle;
	vector<Mat> object_redtri;
	vector<Mat> object_bluecircle;
	vector<Mat> object_bluerect;
	vector<Mat> object_yellowtri;
	//����ʶ��������
	vector<int> recognize_redcircle;
	vector<int> recognize_redtri;
	vector<int> recognize_bluecircle;
	vector<int> recognize_bluerect;
	vector<int> recognize_yellowtri;
private:                   //����������
	CvANN_MLP bpredcircle;
	CvANN_MLP bpredtri;
	CvANN_MLP bpbluecircle;
	CvANN_MLP bpbluerect;
	CvANN_MLP bpyellowtri;
private:
	void displayimage(QLabel *label,Mat &image);
	void printrecinformation(vector<int> &recvecotr,const char TSR_INFORMATION[][30]);
private slots:
	void openimg();
	void imgsegment();
	void imgrecognize();
	void windowquit();
};

#endif // TESTQT_H
