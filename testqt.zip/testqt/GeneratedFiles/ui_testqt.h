/********************************************************************************
** Form generated from reading UI file 'testqt.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTQT_H
#define UI_TESTQT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_testqtClass
{
public:
    QWidget *centralWidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *objectnum;
    QLineEdit *ob1;
    QLineEdit *ob2;
    QLineEdit *ob3;
    QLineEdit *ob4;
    QLineEdit *ob5;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *objectlabel;
    QLabel *label_6;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_7;
    QLabel *label_5;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *himage;
    QLabel *showsrcimage;
    QLabel *showrimage;
    QLabel *showyimage;
    QLabel *showbimage;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *himagelabel;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *recognizelabel;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_14;
    QLabel *label_13;
    QLabel *label_10;
    QWidget *verticalLayoutWidget_4;
    QVBoxLayout *hrecnum;
    QLineEdit *rec1;
    QLineEdit *rec2;
    QLineEdit *rec3;
    QLineEdit *rec4;
    QLineEdit *rec5;
    QWidget *verticalLayoutWidget_5;
    QVBoxLayout *hbutton;
    QPushButton *open;
    QPushButton *segment;
    QPushButton *recognize;
    QPushButton *quit;
    QTextEdit *textEdit;
    QLabel *about;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *testqtClass)
    {
        if (testqtClass->objectName().isEmpty())
            testqtClass->setObjectName(QStringLiteral("testqtClass"));
        testqtClass->resize(1059, 543);
        centralWidget = new QWidget(testqtClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayoutWidget = new QWidget(centralWidget);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(170, 290, 81, 171));
        objectnum = new QVBoxLayout(verticalLayoutWidget);
        objectnum->setSpacing(6);
        objectnum->setContentsMargins(11, 11, 11, 11);
        objectnum->setObjectName(QStringLiteral("objectnum"));
        objectnum->setContentsMargins(0, 0, 0, 0);
        ob1 = new QLineEdit(verticalLayoutWidget);
        ob1->setObjectName(QStringLiteral("ob1"));

        objectnum->addWidget(ob1);

        ob2 = new QLineEdit(verticalLayoutWidget);
        ob2->setObjectName(QStringLiteral("ob2"));

        objectnum->addWidget(ob2);

        ob3 = new QLineEdit(verticalLayoutWidget);
        ob3->setObjectName(QStringLiteral("ob3"));

        objectnum->addWidget(ob3);

        ob4 = new QLineEdit(verticalLayoutWidget);
        ob4->setObjectName(QStringLiteral("ob4"));

        objectnum->addWidget(ob4);

        ob5 = new QLineEdit(verticalLayoutWidget);
        ob5->setObjectName(QStringLiteral("ob5"));

        objectnum->addWidget(ob5);

        verticalLayoutWidget_2 = new QWidget(centralWidget);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(20, 290, 121, 171));
        objectlabel = new QVBoxLayout(verticalLayoutWidget_2);
        objectlabel->setSpacing(6);
        objectlabel->setContentsMargins(11, 11, 11, 11);
        objectlabel->setObjectName(QStringLiteral("objectlabel"));
        objectlabel->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(verticalLayoutWidget_2);
        label_6->setObjectName(QStringLiteral("label_6"));

        objectlabel->addWidget(label_6);

        label_8 = new QLabel(verticalLayoutWidget_2);
        label_8->setObjectName(QStringLiteral("label_8"));

        objectlabel->addWidget(label_8);

        label_9 = new QLabel(verticalLayoutWidget_2);
        label_9->setObjectName(QStringLiteral("label_9"));

        objectlabel->addWidget(label_9);

        label_7 = new QLabel(verticalLayoutWidget_2);
        label_7->setObjectName(QStringLiteral("label_7"));

        objectlabel->addWidget(label_7);

        label_5 = new QLabel(verticalLayoutWidget_2);
        label_5->setObjectName(QStringLiteral("label_5"));

        objectlabel->addWidget(label_5);

        horizontalLayoutWidget = new QWidget(centralWidget);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(15, 40, 301, 231));
        himage = new QHBoxLayout(horizontalLayoutWidget);
        himage->setSpacing(6);
        himage->setContentsMargins(11, 11, 11, 11);
        himage->setObjectName(QStringLiteral("himage"));
        himage->setContentsMargins(0, 0, 0, 0);
        showsrcimage = new QLabel(horizontalLayoutWidget);
        showsrcimage->setObjectName(QStringLiteral("showsrcimage"));
        showsrcimage->setText(QStringLiteral("TextLabel"));

        himage->addWidget(showsrcimage);

        showrimage = new QLabel(horizontalLayoutWidget);
        showrimage->setObjectName(QStringLiteral("showrimage"));

        himage->addWidget(showrimage);

        showyimage = new QLabel(horizontalLayoutWidget);
        showyimage->setObjectName(QStringLiteral("showyimage"));

        himage->addWidget(showyimage);

        showbimage = new QLabel(horizontalLayoutWidget);
        showbimage->setObjectName(QStringLiteral("showbimage"));

        himage->addWidget(showbimage);

        horizontalLayoutWidget_2 = new QWidget(centralWidget);
        horizontalLayoutWidget_2->setObjectName(QStringLiteral("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(19, 10, 1021, 21));
        himagelabel = new QHBoxLayout(horizontalLayoutWidget_2);
        himagelabel->setSpacing(6);
        himagelabel->setContentsMargins(11, 11, 11, 11);
        himagelabel->setObjectName(QStringLiteral("himagelabel"));
        himagelabel->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(horizontalLayoutWidget_2);
        label->setObjectName(QStringLiteral("label"));

        himagelabel->addWidget(label);

        label_2 = new QLabel(horizontalLayoutWidget_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        himagelabel->addWidget(label_2);

        label_3 = new QLabel(horizontalLayoutWidget_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        himagelabel->addWidget(label_3);

        label_4 = new QLabel(horizontalLayoutWidget_2);
        label_4->setObjectName(QStringLiteral("label_4"));

        himagelabel->addWidget(label_4);

        verticalLayoutWidget_3 = new QWidget(centralWidget);
        verticalLayoutWidget_3->setObjectName(QStringLiteral("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(280, 290, 121, 171));
        recognizelabel = new QVBoxLayout(verticalLayoutWidget_3);
        recognizelabel->setSpacing(6);
        recognizelabel->setContentsMargins(11, 11, 11, 11);
        recognizelabel->setObjectName(QStringLiteral("recognizelabel"));
        recognizelabel->setContentsMargins(0, 0, 0, 0);
        label_11 = new QLabel(verticalLayoutWidget_3);
        label_11->setObjectName(QStringLiteral("label_11"));

        recognizelabel->addWidget(label_11);

        label_12 = new QLabel(verticalLayoutWidget_3);
        label_12->setObjectName(QStringLiteral("label_12"));

        recognizelabel->addWidget(label_12);

        label_14 = new QLabel(verticalLayoutWidget_3);
        label_14->setObjectName(QStringLiteral("label_14"));

        recognizelabel->addWidget(label_14);

        label_13 = new QLabel(verticalLayoutWidget_3);
        label_13->setObjectName(QStringLiteral("label_13"));

        recognizelabel->addWidget(label_13);

        label_10 = new QLabel(verticalLayoutWidget_3);
        label_10->setObjectName(QStringLiteral("label_10"));

        recognizelabel->addWidget(label_10);

        verticalLayoutWidget_4 = new QWidget(centralWidget);
        verticalLayoutWidget_4->setObjectName(QStringLiteral("verticalLayoutWidget_4"));
        verticalLayoutWidget_4->setGeometry(QRect(440, 290, 81, 171));
        hrecnum = new QVBoxLayout(verticalLayoutWidget_4);
        hrecnum->setSpacing(6);
        hrecnum->setContentsMargins(11, 11, 11, 11);
        hrecnum->setObjectName(QStringLiteral("hrecnum"));
        hrecnum->setContentsMargins(0, 0, 0, 0);
        rec1 = new QLineEdit(verticalLayoutWidget_4);
        rec1->setObjectName(QStringLiteral("rec1"));

        hrecnum->addWidget(rec1);

        rec2 = new QLineEdit(verticalLayoutWidget_4);
        rec2->setObjectName(QStringLiteral("rec2"));

        hrecnum->addWidget(rec2);

        rec3 = new QLineEdit(verticalLayoutWidget_4);
        rec3->setObjectName(QStringLiteral("rec3"));

        hrecnum->addWidget(rec3);

        rec4 = new QLineEdit(verticalLayoutWidget_4);
        rec4->setObjectName(QStringLiteral("rec4"));

        hrecnum->addWidget(rec4);

        rec5 = new QLineEdit(verticalLayoutWidget_4);
        rec5->setObjectName(QStringLiteral("rec5"));

        hrecnum->addWidget(rec5);

        verticalLayoutWidget_5 = new QWidget(centralWidget);
        verticalLayoutWidget_5->setObjectName(QStringLiteral("verticalLayoutWidget_5"));
        verticalLayoutWidget_5->setGeometry(QRect(800, 290, 91, 181));
        hbutton = new QVBoxLayout(verticalLayoutWidget_5);
        hbutton->setSpacing(6);
        hbutton->setContentsMargins(11, 11, 11, 11);
        hbutton->setObjectName(QStringLiteral("hbutton"));
        hbutton->setContentsMargins(0, 0, 0, 0);
        open = new QPushButton(verticalLayoutWidget_5);
        open->setObjectName(QStringLiteral("open"));
        open->setAutoDefault(true);

        hbutton->addWidget(open);

        segment = new QPushButton(verticalLayoutWidget_5);
        segment->setObjectName(QStringLiteral("segment"));

        hbutton->addWidget(segment);

        recognize = new QPushButton(verticalLayoutWidget_5);
        recognize->setObjectName(QStringLiteral("recognize"));

        hbutton->addWidget(recognize);

        quit = new QPushButton(verticalLayoutWidget_5);
        quit->setObjectName(QStringLiteral("quit"));
        quit->setAutoRepeat(false);
        quit->setAutoRepeatInterval(100);
        quit->setAutoDefault(false);

        hbutton->addWidget(quit);

        textEdit = new QTextEdit(centralWidget);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(580, 290, 171, 171));
        about = new QLabel(centralWidget);
        about->setObjectName(QStringLiteral("about"));
        about->setGeometry(QRect(930, 300, 61, 151));
        testqtClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(testqtClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1059, 23));
        testqtClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(testqtClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        testqtClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(testqtClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        testqtClass->setStatusBar(statusBar);

        retranslateUi(testqtClass);
        QObject::connect(open, SIGNAL(clicked()), testqtClass, SLOT(openimg()));
        QObject::connect(segment, SIGNAL(clicked()), testqtClass, SLOT(imgsegment()));
        QObject::connect(recognize, SIGNAL(clicked()), testqtClass, SLOT(imgrecognize()));
        QObject::connect(quit, SIGNAL(clicked()), testqtClass, SLOT(windowquit()));
        QObject::connect(recognize, SIGNAL(clicked()), testqtClass, SLOT(imgrecognize()));

        QMetaObject::connectSlotsByName(testqtClass);
    } // setupUi

    void retranslateUi(QMainWindow *testqtClass)
    {
        testqtClass->setWindowTitle(QApplication::translate("testqtClass", "testqt", 0));
        label_6->setText(QApplication::translate("testqtClass", "\347\272\242\350\211\262\345\234\206\345\275\242\346\240\207\345\277\227---->", 0));
        label_8->setText(QApplication::translate("testqtClass", "\347\272\242\350\211\262\344\270\211\350\247\222\345\275\242\346\240\207\345\277\227-->", 0));
        label_9->setText(QApplication::translate("testqtClass", "\350\223\235\350\211\262\345\234\206\345\275\242\346\240\207\345\277\227---->", 0));
        label_7->setText(QApplication::translate("testqtClass", "\350\223\235\350\211\262\347\237\251\345\275\242\346\240\207\345\277\227---->", 0));
        label_5->setText(QApplication::translate("testqtClass", "\351\273\204\350\211\262\344\270\211\350\247\222\345\275\242\346\240\207\345\277\227-->", 0));
        showrimage->setText(QApplication::translate("testqtClass", "TextLabel", 0));
        showyimage->setText(QApplication::translate("testqtClass", "TextLabel", 0));
        showbimage->setText(QApplication::translate("testqtClass", "TextLabel", 0));
        label->setText(QApplication::translate("testqtClass", "\345\216\237\345\233\276\345\203\217", 0));
        label_2->setText(QApplication::translate("testqtClass", "R\345\210\206\345\211\262", 0));
        label_3->setText(QApplication::translate("testqtClass", "Y\345\210\206\345\211\262", 0));
        label_4->setText(QApplication::translate("testqtClass", "B\345\210\206\345\211\262", 0));
        label_11->setText(QApplication::translate("testqtClass", "\350\257\206\345\210\253------------>", 0));
        label_12->setText(QApplication::translate("testqtClass", "\350\257\206\345\210\253------------>", 0));
        label_14->setText(QApplication::translate("testqtClass", "\350\257\206\345\210\253------------>", 0));
        label_13->setText(QApplication::translate("testqtClass", "\350\257\206\345\210\253------------>", 0));
        label_10->setText(QApplication::translate("testqtClass", "\350\257\206\345\210\253------------>", 0));
        open->setText(QApplication::translate("testqtClass", "open", 0));
        segment->setText(QApplication::translate("testqtClass", "segment", 0));
        recognize->setText(QApplication::translate("testqtClass", "recognize", 0));
        quit->setText(QApplication::translate("testqtClass", "quit", 0));
        textEdit->setHtml(QApplication::translate("testqtClass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", 0));
        about->setText(QApplication::translate("testqtClass", "TextLabel", 0));
    } // retranslateUi

};

namespace Ui {
    class testqtClass: public Ui_testqtClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTQT_H
