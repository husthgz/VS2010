#include  "image_segmentation.h"
#include  "zernike.h"
#define   innode   8 //�����ڵ����
#define   TSR_RECOGNIZE_WRONG   100
int convertbinary2int(Mat &outdata);
void recognize(vector<Mat> &object,vector<int> &redata,CvANN_MLP &bpnet);


