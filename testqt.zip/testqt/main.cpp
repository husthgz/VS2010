#include "testqt.h"
#include <QtWidgets/QApplication>
#include <QTextCodec>
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	a.connect( &a,SIGNAL(lastWindowClosed()),  &a, SLOT(quit()));  
	testqt w;
	w.show();
	return a.exec();
}
