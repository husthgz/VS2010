#include "TSR.h"
#include "opencvhead.h"
int convertbinary2int(Mat &outdata)
{  
	if (outdata.empty()||outdata.rows!=1)
	{   
		    cout<<"fuction at  convetbinary2int :input is  empty or wrong"<<endl;
			return TSR_RECOGNIZE_WRONG;
	}
	/*double   curerror=0.0;
	double   minerror=100.0;
	double  *rdata=outdata.ptr<double>(0);
	int     mark;*/
	/*for(int i=0;i<ln;i++)  //����һ
	{
		curerror=0;
		for (int j=0;j<outdata.cols;j++)
		{
			 if (i==0)
			     cout<<rdata[j]<<endl;
			if (rdata[j]>1.1)
			  curerror+=abs(1.0-TSR_TABLE[i][j]);
			else if (rdata[j]<0.01)
			  curerror+=abs(0.0-TSR_TABLE[i][j]);
			else
			  curerror+=abs(rdata[j]-TSR_TABLE[i][j]);
		}
		cout<<i<<" "<<curerror<<endl;
		if (curerror<minerror)
		{
			mark=i;
			minerror=curerror;
		}
	}
	if (minerror>1.0)
	  return TSR_RECOGNIZE_WRONG;
	return mark;*/
    int mark;
	double maxvalue=0.0;
	double  *rdata=outdata.ptr<double>(0);
    for (int j=0;j<outdata.cols;j++)
	{
		cout<<rdata[j]<<endl;
		if (rdata[j]>maxvalue)
		{
			mark=j;
			maxvalue=rdata[j];
		}
		else
			continue;		 
    }
	if (maxvalue<0.65)
	  return TSR_RECOGNIZE_WRONG;
	return mark;
}
void recognize(vector<Mat> &object,vector<int> &redata,CvANN_MLP &bpnet)
{
	redata.clear();
	if (object.empty())
	{
		return ;
	}
	for (unsigned int i=0;i<object.size();i++)
	{   	
		double ze[innode]={0.0};
		getZernikeMoment2(object[i],ze);
		Mat indata(1,innode,CV_64FC1,ze);
		Mat outdata;
		bpnet.predict(indata,outdata);
		redata.push_back(convertbinary2int(outdata));
	}
}