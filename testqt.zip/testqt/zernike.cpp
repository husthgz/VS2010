#include "zernike.h"
uchar J_getpixel(const Mat &src,const int x, const int y)
{
	if (src.at<uchar>(y,x)>0)
		return 1;
	else
		return 0;
}

//�׳�
double Factorial( int n )
{
	if( n < 0 )
		return -1;
	double m = 39916800;
	for(int i = 12 ; i <= n ; i++)
	{
		m *= i;
	}
	return m;
}
//�׳���������÷����ã�����ٶ�
double factorials[11] = {1 , 1 , 2 , 6 , 24 , 120 , 720 , 5040 , 40320 , 362880 , 39916800};

double getmaxradius(int srcwidth,int srcheight,int x0,int y0)
{
	double lefttop = sqrt(((double)0 - x0)*(0- x0) + (0 - y0)*(0 - y0));
	double righttop = sqrt(((double)srcwidth-1  - x0)*(srcwidth-1 - x0) + (0 - y0)*(0- y0));
	double leftbottom = sqrt(((double)0 - x0)*(0 - x0) + (srcheight-1 - y0)*(srcheight-1 - y0));
	double rightbottom = sqrt(((double)srcwidth-1 - x0)*(srcwidth-1 - x0) + (srcheight-1 - y0)*(srcheight-1 - y0));

	double maxRadii = lefttop;
	maxRadii < righttop ? righttop : maxRadii;
	maxRadii < leftbottom ? leftbottom : maxRadii;
	maxRadii < rightbottom ? rightbottom : maxRadii;

	return maxRadii;
}
//��ͼ��ӳ�䵽��λԲ����ȡ���ؼ�����뾶
double GetRadii(int x0,int y0,int x,int y,double maxRadii)
{
	double Radii = sqrt(((double)x - x0)*(x - x0) + (y - y0)*(y - y0))/maxRadii;
	if(Radii > 0.75)
		Radii = 0.0;
	else
	   Radii*=1.2;
	return Radii;
}

//��ͼ��ӳ�䵽��λԲ����ȡ���ؼ�����Ƕ�
double GetAngle(int x,int y,int x0,int y0)
{
	double x_unity = (x - x0);
	double y_unity = (y - y0);
	return atan2(y_unity,x_unity);
}

//Zernike�����  ��ȡzernike��5~12��
void getZernikeMoment(const Mat &src, double Ze[8])
{
	double zr= 0.0;     //ʵ�����鲿
	double zi= 0.0;
	int srcWidth=src.cols;
	int srcHeight=src.rows;

    //�Ż�����  �ȼ������������
    Moments mts;
	mts=moments(src,true);
	int x0 = (int)(mts.m10/mts.m00);      //��������
	int y0 = (int)(mts.m01/mts.m00);
	double maxradius=srcWidth/2;
	//double maxradius=getmaxradius(srcWidth,srcHeight,x0,y0); //��󳤶� ������һ��
	//����zernike z50~z120
	int n=0,m=0;
	for(int i=0;i<8;i++)
	{
		
		n=TSR_ZERNIKE_TABLE_N[i];
		m=TSR_ZERNIKE_TABLE_M[i];
		double r=0.0;
		for(int y = 0 ; y < srcHeight ; y++)
		{
			for (int x = 0 ; x < srcWidth ; x++)
			{
				for(int s = 0 ; s <= (n - m)/2 ; s++)
				{
					r=GetRadii(x0, y0, x, y,maxradius);
					if (r<0.001)
						continue;
					zr += pow( -1.0, s )
						* ( n - s > 10 ? Factorial( n - s ) : factorials[ n - s ] )
						* pow(r, n - 2 * s )
						/ ( ( s > 10 ? Factorial( s ) : factorials[ s ] )
						* ( ( n + m ) / 2 - s > 10 ? Factorial( ( n + m ) / 2 - s ) : factorials[ ( n + m ) / 2 - s ] )
						* ( ( n - m ) / 2 - s > 10 ? Factorial( ( n - m ) / 2 - s ) : factorials[ ( n - m ) / 2 - s ] ) );
				}
				uchar fxy=J_getpixel(src,x,y);
				Ze[i]+= zr*fxy* cos( m * GetAngle(x, y,x0,y0) );//ʵ��

				zi += zr *fxy * sin( m * GetAngle(x, y,x0,y0) );//�鲿

				zr = 0.0;
			}
		}
		Ze[i]= log(sqrt(Ze[i]*Ze[i] + zi*zi)*(n+1)/PI/mts.m00)/8;
		zi=0.0;
		//cout<<"ZE  "<<i<<"  "<<Ze[i]<<endl;
	}
}
void getZernikeMoment2(const Mat &src, double Ze[8])
{
	double zr= 0.0;     //ʵ�����鲿
	double zi= 0.0;
	int srcWidth=src.cols;
	int srcHeight=src.rows;
	//�Ż�����  �ȼ������������
	Moments mts;
	mts=moments(src,false);
	int x0 = (int)(mts.m10/mts.m00);      //��������
	int y0 = (int)(mts.m01/mts.m00);
	//double maxradius=getmaxradius(srcWidth,srcHeight,x0,y0); //��󳤶� ������һ��
	double maxradius=srcWidth/2;
	//����zernike
	int n=0,m=0;
	for(int i=0;i<8;i++)
	{
		n=TSR_ZERNIKE_TABLE_N[i];
		m=TSR_ZERNIKE_TABLE_M[i];
		double r=0.0;
		for(int y = 0 ; y < srcHeight ; y++)
		{
			for (int x = 0 ; x < srcWidth ; x++)
			{
				for(int s = 0 ; (s <= (n - m)/2 ) && n >= m ; s++)
				{
					r=GetRadii(x0, y0, x, y,maxradius);
					if (r<0.001)
					  continue;
					zr += pow( -1.0, s )
						* ( n - s > 10 ? Factorial( n - s ) : factorials[ n - s ] )
						* pow(r, n - 2 * s )
						/ ( ( s > 10 ? Factorial( s ) : factorials[ s ] )
						* ( ( n + m ) / 2 - s > 10 ? Factorial( ( n + m ) / 2 - s ) : factorials[ ( n + m ) / 2 - s ] )
						* ( ( n - m ) / 2 - s > 10 ? Factorial( ( n - m ) / 2 - s ) : factorials[ ( n - m ) / 2 - s ] ) );
				}
				uchar fxy=J_getpixel(src,x,y);
				Ze[i]+= zr*fxy* cos( m * GetAngle(x, y,x0,y0) );//ʵ��

				zi += zr *fxy * sin( m * GetAngle(x, y,x0,y0) );//�鲿

				zr = 0.0;
			}
		}
		Ze[i]=abs(sqrt(Ze[i]*Ze[i] + zi*zi)*(n+1)/PI)/(mts.m00/255)/TSR_ZERNIKE_NORMALIZAITON[i];
		//cout<<"zi "<<zi<<endl;
		//cout<<"ze "<<Ze[i]<<endl;
		zi=0.0;
		//cout<<"ZE  "<<i<<"  "<<Ze[i]<<endl;
	}
}
void gethumoments(const Mat &src, double hu[7])
{
	Moments mm;
	mm=moments(src,true);
	double hutmp[7]={0.0};
	HuMoments(mm,hutmp);
	for(int i=0;i<7;i++)
		hu[i]=log(fabs(hutmp[i]));
}

