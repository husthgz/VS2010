#include "testqt.h"

testqt::testqt(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	//���ڳ�ʼ������
	this->setFixedSize(1120,535);
	this->setWindowTitle(QStringLiteral("��ͨ��־ʶ��ϵͳ"));
	//imagelabel
	ui.horizontalLayoutWidget_2->setGeometry(QRect(19,11,1080,20));
	//imageshow
	ui.horizontalLayoutWidget->setGeometry(QRect(19,11+30,1080,270));
	ui.showsrcimage->resize(270,270);
	ui.showrimage->resize(270,270);
	ui.showyimage->resize(270,270);
	ui.showbimage->resize(270,270);
	//objectlabel
	ui.verticalLayoutWidget_2->setGeometry(QRect(19,334,120,170));
	//objectnum
	ui.verticalLayoutWidget->setGeometry(QRect(139+30,334,82,170));
	//reclabel
	ui.verticalLayoutWidget_3->setGeometry(QRect(290,334,120,170));
	//recognizenum
	ui.verticalLayoutWidget_4->setGeometry(QRect(410+30,334,82,170));
	//textedit
	ui.textEdit->setGeometry(QRect(560+45,342,180,151));
	//button
	ui.verticalLayoutWidget_5->setGeometry(QRect(835,334,100,170));
	//about
	ui.about->setGeometry(QRect(935+30,324,150,170));
	//��ʼ������ͼƬ
	srcimage=imread("Resources/srcimage.jpg");
	displayimage(ui.showsrcimage,srcimage);
	rimage=imread("Resources/rimage.jpg");
	displayimage(ui.showrimage,rimage);
	yimage=imread("Resources/yimage.jpg");
	displayimage(ui.showyimage,yimage);
	bimage=imread("Resources/bimage.jpg");
	displayimage(ui.showbimage,bimage);
	aboutimage=imread("Resources/about.jpg");
	displayimage(ui.about,aboutimage);
	//lineedit���� 
	ui.ob1->setReadOnly(true);
	ui.ob2->setReadOnly(true);
	ui.ob3->setReadOnly(true);
	ui.ob4->setReadOnly(true);
	ui.ob5->setReadOnly(true);
	ui.rec1->setReadOnly(true);
	ui.rec2->setReadOnly(true);
	ui.rec3->setReadOnly(true);
	ui.rec4->setReadOnly(true);
	ui.rec5->setReadOnly(true);
	//ˮƽ����
	ui.ob1->setAlignment(Qt::AlignHCenter);
	ui.ob2->setAlignment(Qt::AlignHCenter);
	ui.ob3->setAlignment(Qt::AlignHCenter);
	ui.ob4->setAlignment(Qt::AlignHCenter);
	ui.ob5->setAlignment(Qt::AlignHCenter);
	ui.rec1->setAlignment(Qt::AlignHCenter);
	ui.rec2->setAlignment(Qt::AlignHCenter);
	ui.rec3->setAlignment(Qt::AlignHCenter);
	ui.rec4->setAlignment(Qt::AlignHCenter);
	ui.rec5->setAlignment(Qt::AlignHCenter);
	//TextEdit
	ui.textEdit->setReadOnly(true);
	ui.textEdit->setFontPointSize(10);
	ui.textEdit->setTextColor(QColor(0,0,204));
	ui.textEdit->setAlignment(Qt::AlignCenter);
	ui.textEdit->append(QStringLiteral("------ʶ����Ϣ------"));
	//����������
	bpredcircle.load("data/redcircle.xml");
	bpredtri.load("data/redtri.xml");
	bpbluecircle.load("data/bluecircle.xml");
	bpbluerect.load("data/bluerect.xml");
	bpyellowtri.load("data/yellowtri.xml");
}

testqt::~testqt()
{
	//�ͷ��ڴ�
	srcimage.release();
	rimage.release();
	bimage.release();
	yimage.release();
	object_redcircle.~vector<Mat>();
	object_redtri.~vector<Mat>();
	object_bluecircle.~vector<Mat>();
	object_bluerect.~vector<Mat>();
	object_yellowtri.~vector<Mat>();
	recognize_redcircle.~vector<int>();
	recognize_redtri.~vector<int>();
	recognize_bluecircle.~vector<int>();
	recognize_bluerect.~vector<int>();
	recognize_yellowtri.~vector<int>();
}
void testqt:: openimg()
{  
	QString fileName = QFileDialog::getOpenFileName(this,tr("Open Image"),
		".",tr("Image Files (*.png *.jpg *.bmp)"));
	if (fileName.isEmpty())
		return;
	srcimage = imread(fileName.toLocal8Bit().data());
	displayimage(ui.showsrcimage,srcimage);
	//clear
	ui.ob1->clear();
	ui.ob2->clear();
	ui.ob3->clear();
	ui.ob4->clear();
	ui.ob5->clear();
	ui.rec1->clear();
	ui.rec2->clear();
	ui.rec3->clear();
	ui.rec4->clear();
	ui.rec5->clear();
}
void testqt::displayimage(QLabel *label,Mat &image)
{
	if (image.empty())
	  return;
	QImage qimg;
	Mat tmp_img;
	image.copyTo(tmp_img);
	if (tmp_img.channels()==3)
	{ 
		cvtColor(tmp_img, tmp_img, CV_RGB2RGBA);//ͼ����QT��ʾǰ������ת����QImage��ʽ����RGBA��ʽת����RGB
		qimg= QImage((const unsigned char*)(tmp_img.data), 
			tmp_img.cols, tmp_img.rows, QImage::Format_RGB32); 
	}
	else
	{   
		cvtColor(tmp_img,tmp_img,CV_GRAY2RGBA);
		qimg= QImage((const unsigned char*)(tmp_img.data), 
			tmp_img.cols, tmp_img.rows, QImage::Format_RGB32); 
	}
	double imgscale=1.001;
	if (tmp_img.rows>label->height()||tmp_img.cols>label->width())//����ͼƬ
	{
		
		if (tmp_img.rows>tmp_img.cols)
			imgscale=double(tmp_img.rows)/label->height();
		else
			imgscale=double(tmp_img.cols)/label->width();
	}
	qimg=qimg.scaled(qimg.width()/imgscale,qimg.height()/imgscale,Qt::KeepAspectRatio);
	label->setPixmap(QPixmap::fromImage(qimg));  
	label->show();
	tmp_img.release();
}
void testqt::imgsegment()
{
	if (srcimage.empty())
	{
		return;
	}
	colordivision(srcimage,rimage,yimage,bimage);
	//ˢ����ʾ
	displayimage(ui.showrimage,rimage);
	displayimage(ui.showbimage,bimage);
	displayimage(ui.showyimage,yimage);
	//���Ŀ��
	objectsegment(object_redcircle,srcimage,rimage,TSR_REDCOLOR,TSR_CIRCLE,true);
	objectsegment(object_redtri,srcimage,rimage,TSR_REDCOLOR,TSR_TRIANGLE,true);
	objectsegment(object_bluecircle,srcimage,bimage,TSR_BLUECOLOR,TSR_CIRCLE,true);
	objectsegment(object_bluerect,srcimage,bimage,TSR_BLUECOLOR,TSR_RECTANGLE,true);
	objectsegment(object_yellowtri,srcimage,yimage,TSR_YELLOWCOLOR,TSR_TRIANGLE,true);
	
	displayimage(ui.showsrcimage,srcimage);
	//��ʾĿ�����
	ui.ob1->setText(QString::number(object_redcircle.size(),10));
	ui.ob2->setText(QString::number(object_redtri.size(),10));
	ui.ob3->setText(QString::number(object_bluecircle.size(),10));
	ui.ob4->setText(QString::number(object_bluerect.size(),10));
	ui.ob5->setText(QString::number(object_yellowtri.size(),10));
	//
	imshow("object0",object_redcircle[0]);
	waitKey(0);
}
void testqt::imgrecognize()
{
	//ʶ��Ŀ��
	recognize(object_redcircle,recognize_redcircle,bpredcircle);
	recognize(object_redtri,recognize_redtri,bpredtri);
	recognize(object_bluecircle,recognize_bluecircle,bpbluecircle);
	recognize(object_bluerect,recognize_bluerect,bpbluerect);
	recognize(object_yellowtri,recognize_yellowtri,bpyellowtri);
	//��ʾʶ�����
	ui.rec1->setText(QString::number(recognize_redcircle.size(),10));
	ui.rec2->setText(QString::number(recognize_redtri.size(),10));
	ui.rec3->setText(QString::number(recognize_bluecircle.size(),10));
	ui.rec4->setText(QString::number(recognize_bluerect.size(),10));
	ui.rec5->setText(QString::number(recognize_yellowtri.size(),10));
	//��ʾʶ����Ϣ
	//��Ϣͷ
	ui.textEdit->clear();
	ui.textEdit->setAlignment(Qt::AlignCenter);
	ui.textEdit->append(QStringLiteral("------ʶ����Ϣ------"));
	//��ʾʶ����Ϣ
	printrecinformation(recognize_redcircle,TSR_TABLE_REDCIRCLE);
}
void testqt::windowquit()
{
	this->close();
}
void testqt::printrecinformation(vector<int> &recvecotr,const char TSR_INFORMATION[][30])
{
	for (unsigned int i=0;i<recvecotr.size();i++)
	{
	    if(recvecotr[i]<10)
		{
		QString qtmp= QString(QString::fromLocal8Bit(TSR_INFORMATION[recvecotr[i]]));
		ui.textEdit->append(qtmp); 
		}
	}
}

